from aiogram.fsm.state import State, StatesGroup

class SearchState(StatesGroup):
    waiting_for_query = State()

class OrderState(StatesGroup):
    waiting_for_name = State()
    waiting_for_phone = State()
    waiting_for_address = State()
    waiting_for_comment = State()
    confirming = State()

class AdminAddBookState(StatesGroup):
    waiting_for_title = State()
    waiting_for_author = State()
    waiting_for_category = State()
    waiting_for_description = State()
    waiting_for_price = State()
    waiting_for_pages = State()
    waiting_for_format = State()
    waiting_for_image = State()
    waiting_for_bestseller = State()
    waiting_for_new = State()

class AdminEditBookState(StatesGroup):
    selecting_book = State()
    selecting_field = State()
    waiting_for_value = State()

class AdminCategoryState(StatesGroup):
    waiting_for_category_name = State()

class AdminMenuEditState(StatesGroup):
    waiting_for_content = State()

class AdminButtonEditState(StatesGroup):
    waiting_for_title = State()
    waiting_for_reply_text = State()
    waiting_for_custom_title = State()
    waiting_for_custom_text = State()
