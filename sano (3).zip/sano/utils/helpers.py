from typing import Any

def format_price(amount: float) -> str:
    """Format numeric price into human-readable UZS string. e.g. 45000 -> 45 000 so‘m"""
    formatted = f"{int(amount):,}".replace(",", " ")
    return f"{formatted} so‘m"

def format_order_status(status: str) -> str:
    """Translate internal order status string to Uzbek Latin with emoji."""
    statuses = {
        "new": "📌 Yangi",
        "confirmed": "✅ Qabul qilindi",
        "shipping": "🚚 Yetkazishga berildi",
        "delivered": "✅ Yetkazildi",
        "cancelled": "❌ Bekor qilingan"
    }
    return statuses.get(status, f"❓ {status}")

def format_book_card(book: Any, detailed: bool = False) -> str:
    """Format book details into message text."""
    title = f"📕 {book.title}"
    author = f"✍️ Muallif: {book.author}"
    price = f"💰 Narxi: {format_price(book.price)}"
    pages = f"📄 {book.pages} bet"
    fmt = f"📐 Format: {book.format}"
    cat_name = book.category.name if getattr(book, "category", None) else "Noma'lum"
    category = f"📂 Kategoriya: {cat_name}"

    badges = []
    if getattr(book, "is_bestseller", False):
        badges.append("🔥 Bestseller")
    if getattr(book, "is_new", False):
        badges.append("🆕 Yangi")

    badge_str = f" ({', '.join(badges)})" if badges else ""

    if not detailed:
        desc = book.description[:120] + "..." if len(book.description) > 120 else book.description
        return (
            f"{title}{badge_str}\n\n"
            f"{author}\n"
            f"{price}\n"
            f"{pages}\n"
            f"{fmt}\n"
            f"{category}\n\n"
            f"Kitob haqida:\n{desc}"
        )
    else:
        return (
            f"{title}{badge_str}\n\n"
            f"{author}\n"
            f"{price}\n"
            f"{pages}\n"
            f"{fmt}\n"
            f"{category}\n\n"
            f"Kitob haqida to‘liq:\n{book.description}"
        )

def format_order_user_view(order: Any) -> str:
    """Format customer order summary."""
    lines = [
        f"📦 BUYURTMA #{order.id}",
        f"Status: {format_order_status(order.status)}",
        f"Sana: {order.created_at.strftime('%d.%m.%Y %H:%M') if order.created_at else ''}",
        "\n📚 Mahsulotlar:"
    ]
    for idx, item in enumerate(order.order_items, 1):
        book_title = item.book.title if item.book else "Kitob"
        lines.append(f"{idx}. {book_title} × {item.quantity} ({format_price(item.price * item.quantity)})")

    lines.append(f"\n💰 Jami: {format_price(order.total_price)}")
    lines.append(f"📱 Telefon: {order.phone}")
    lines.append(f"📍 Manzil: {order.address}")
    if order.comment:
        lines.append(f"💬 Izoh: {order.comment}")

    return "\n".join(lines)

def format_order_admin_view(order: Any) -> str:
    """Format notification sent to Admin when order is placed or updated."""
    lines = [
        f"🚨 YANGI BUYURTMA #{order.id}",
        "\n📚 KITOBLAR:\n"
    ]

    for idx, item in enumerate(order.order_items, 1):
        book_title = item.book.title if item.book else "Kitob"
        item_total = item.price * item.quantity
        lines.append(
            f"{idx}. {book_title} × {item.quantity}\n"
            f"   {format_price(item.price)} × {item.quantity} = {format_price(item_total)}"
        )

    lines.append(f"\n💰 JAMI: {format_price(order.total_price)}")

    user_info = order.user
    username_str = f"@{user_info.username}" if user_info and user_info.username else "Mavjud emas"
    full_name_str = user_info.full_name if user_info and user_info.full_name else "Mavjud emas"
    tg_id_str = str(user_info.telegram_id) if user_info else "Noma'lum"

    lines.extend([
        "\n👤 MIJOZ:",
        f"Ism: {full_name_str}",
        f"Telefon: {order.phone}",
        f"Manzil: {order.address}",
        f"Telegram: {username_str}",
        f"User ID: {tg_id_str}"
    ])

    if order.comment:
        lines.append(f"💬 Izoh: {order.comment}")

    date_str = order.created_at.strftime("%d.%m.%Y %H:%M") if order.created_at else ""
    lines.append(f"\n🕐 Sana: {date_str}")
    lines.append(f"📌 STATUS: {format_order_status(order.status)}")

    return "\n".join(lines)
