from aiogram import Router, F
from aiogram.filters import CommandStart, StateFilter
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from database.crud import (
    get_or_create_user,
    get_active_reply_buttons,
    get_button_by_title,
    get_categories,
    get_cart,
    get_user_orders,
    search_books
)
from keyboards.reply import main_menu_keyboard, cancel_keyboard
from keyboards.inline import categories_inline_keyboard
from states.states import SearchState

router = Router()

@router.message(CommandStart())
async def cmd_start(message: Message, session: AsyncSession, state: FSMContext) -> None:
    """Handle /start command, register user, and show main menu with active dynamic buttons."""
    await state.clear()
    
    telegram_id = message.from_user.id
    username = message.from_user.username
    full_name = message.from_user.full_name

    await get_or_create_user(session, telegram_id=telegram_id, username=username, full_name=full_name)
    active_buttons = await get_active_reply_buttons(session)

    welcome_text = (
        "📚 SANO BOOKS\n\n"
        "Sevimli kitoblaringizni toping, tanlang va buyurtma bering."
    )
    await message.answer(welcome_text, reply_markup=main_menu_keyboard(active_buttons))

@router.callback_query(F.data == "menu_main")
async def cb_main_menu(callback: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    """Callback returning to main menu overview."""
    await state.clear()
    active_buttons = await get_active_reply_buttons(session)

    welcome_text = (
        "📚 SANO BOOKS\n\n"
        "Sevimli kitoblaringizni toping, tanlang va buyurtma bering."
    )
    await callback.message.answer(welcome_text, reply_markup=main_menu_keyboard(active_buttons))
    await callback.answer()

@router.message(StateFilter(None), F.text)
async def dynamic_button_router(message: Message, session: AsyncSession, state: FSMContext) -> None:
    """Match user button text dynamically against database records."""
    if message.text == "⬅️ Bekor qilish":
        return

    button = await get_button_by_title(session, message.text)
    active_buttons = await get_active_reply_buttons(session)

    if not button:
        return

    # Check button_key to trigger core features or return custom reply_text
    key = button.button_key

    if key == "btn_catalog":
        categories = await get_categories(session)
        if not categories:
            await message.answer("📂 Hozircha kategoriyalar mavjud emas.")
            return
        await message.answer(
            "📚 **Kategoriyani tanlang:**",
            reply_markup=categories_inline_keyboard(categories),
            parse_mode="Markdown"
        )

    elif key == "btn_cart":
        from handlers.cart import render_cart_message
        user = await get_or_create_user(session, message.from_user.id)
        text, keyboard = await render_cart_message(user.id, session)
        await message.answer(text, reply_markup=keyboard, parse_mode="Markdown")

    elif key == "btn_search":
        await state.set_state(SearchState.waiting_for_query)
        await message.answer(
            "🔎 **Kitob nomi yoki muallifini yozing:**",
            reply_markup=cancel_keyboard(),
            parse_mode="Markdown"
        )

    elif key == "btn_my_orders":
        from handlers.orders import show_user_orders
        await show_user_orders(message, session)

    else:
        # Custom or Info button (btn_contact, btn_about, custom buttons)
        reply_content = button.reply_text or "Ma'lumot mavjud emas."
        await message.answer(
            reply_content,
            reply_markup=main_menu_keyboard(active_buttons)
        )
