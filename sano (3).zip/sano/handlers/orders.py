from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

import config
from database.crud import (
    get_or_create_user,
    get_cart,
    add_to_cart,
    create_order,
    get_order_by_id,
    update_order_status,
    get_user_orders,
    get_active_reply_buttons
)
from states.states import OrderState
from keyboards.reply import main_menu_keyboard, contact_request_keyboard, cancel_keyboard
from keyboards.inline import order_confirm_inline_keyboard, admin_order_inline_keyboard
from utils.helpers import format_price, format_order_user_view, format_order_admin_view

router = Router()

@router.callback_query(F.data == "cart_checkout")
async def start_checkout(callback: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    """Begin multi-step checkout process from cart."""
    user = await get_or_create_user(session, callback.from_user.id)
    cart = await get_cart(session, user.id)

    if not cart:
        await callback.answer("Savatchangiz bo‘sh!", show_alert=True)
        return

    await state.set_state(OrderState.waiting_for_name)
    await callback.message.delete()
    
    default_name = user.full_name or ""
    await callback.message.answer(
        f"👤 **To‘liq ism-sharifingizni kiriting:**\n\n(Hozirgi ism: {default_name})",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("buy_now:"))
async def buy_now(callback: CallbackQuery, session: AsyncSession, state: FSMContext) -> None:
    """Add item to cart and immediately initiate checkout."""
    book_id = int(callback.data.split(":")[1])
    user = await get_or_create_user(session, callback.from_user.id)
    await add_to_cart(session, user.id, book_id, quantity=1)

    await state.set_state(OrderState.waiting_for_name)
    await callback.message.delete()
    
    default_name = user.full_name or ""
    await callback.message.answer(
        f"👤 **To‘liq ism-sharifingizni kiriting:**\n\n(Hozirgi ism: {default_name})",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.message(OrderState.waiting_for_name, F.text == "⬅️ Bekor qilish")
@router.message(OrderState.waiting_for_phone, F.text == "⬅️ Bekor qilish")
@router.message(OrderState.waiting_for_address, F.text == "⬅️ Bekor qilish")
@router.message(OrderState.waiting_for_comment, F.text == "⬅️ Bekor qilish")
async def cancel_order(message: Message, state: FSMContext) -> None:
    """Cancel order checkout process."""
    await state.clear()
    await message.answer("Buyurtma jarayoni bekor qilindi.", reply_markup=main_menu_keyboard())

@router.message(OrderState.waiting_for_name)
async def process_name(message: Message, state: FSMContext) -> None:
    """Store customer full name and prompt for phone number."""
    name = message.text.strip()
    await state.update_data(full_name=name)
    await state.set_state(OrderState.waiting_for_phone)
    await message.answer(
        "📱 **Telefon raqamingizni kiriting:**\n\n"
        "Quyidagi tugmani bosing yoki raqamingizni yozib yuboring (+998901234567):",
        reply_markup=contact_request_keyboard(),
        parse_mode="Markdown"
    )

@router.message(OrderState.waiting_for_phone, F.contact)
@router.message(OrderState.waiting_for_phone, F.text)
async def process_phone(message: Message, state: FSMContext) -> None:
    """Store phone number and prompt for delivery address."""
    if message.contact:
        phone = message.contact.phone_number
        if not phone.startswith("+"):
            phone = "+" + phone
    else:
        phone = message.text.strip()

    await state.update_data(phone=phone)
    await state.set_state(OrderState.waiting_for_address)
    await message.answer(
        "📍 **Yetkazib berish manzilini kiriting:**\n\n"
        "Masalan: Toshkent sh., Chilonzor tumani, 19-mavze, 12-uy",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )

@router.message(OrderState.waiting_for_address)
async def process_address(message: Message, state: FSMContext) -> None:
    """Store delivery address and prompt for optional comment."""
    address = message.text.strip()
    await state.update_data(address=address)
    await state.set_state(OrderState.waiting_for_comment)
    await message.answer(
        "💬 **Qo‘shimcha izohingizni yozing:**\n\n"
        "Masalan: Yetkazib beruvchiga qo‘ng‘iroq qilishdan oldin yozib qo‘ying.\n"
        "(O‘tkazib yuborish uchun **-** belgisini yuboring)",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )

@router.message(OrderState.waiting_for_comment)
async def process_comment(message: Message, state: FSMContext, session: AsyncSession) -> None:
    """Store comment and render order confirmation page."""
    comment_text = message.text.strip()
    comment = None if comment_text == "-" else comment_text
    await state.update_data(comment=comment)

    data = await state.get_data()
    user = await get_or_create_user(session, message.from_user.id)
    cart = await get_cart(session, user.id)

    if not cart:
        await state.clear()
        await message.answer("Savatchangiz bo‘sh qolgan.", reply_markup=main_menu_keyboard())
        return

    total_price = sum(item.quantity * item.book.price for item in cart if item.book)

    items_summary = []
    for idx, item in enumerate(cart, 1):
        title = item.book.title if item.book else "Kitob"
        items_summary.append(f"{idx}. {title} × {item.quantity}")

    summary_text = (
        "🛒 **BUYURTMANGIZ**\n\n"
        "📚 **Mahsulotlar:**\n\n"
        f"{'\n'.join(items_summary)}\n\n"
        f"💰 **Jami:** {format_price(total_price)}\n\n"
        f"👤 **Ism:** {data.get('full_name')}\n"
        f"📱 **Telefon:** {data.get('phone')}\n"
        f"📍 **Manzil:** {data.get('address')}\n"
        f"💬 **Izoh:** {data.get('comment') or 'Mavjud emas'}\n\n"
        "Buyurtma berishga tayyormisiz?"
    )

    await state.set_state(OrderState.confirming)
    await message.answer(
        summary_text,
        reply_markup=order_confirm_inline_keyboard(),
        parse_mode="Markdown"
    )

@router.callback_query(OrderState.confirming, F.data == "order_cancel")
async def cancel_confirmation(callback: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    """Cancel order during final confirmation."""
    await state.clear()
    active_btns = await get_active_reply_buttons(session)
    await callback.message.delete()
    await callback.message.answer("Buyurtma bekor qilindi.", reply_markup=main_menu_keyboard(active_btns))
    await callback.answer()

@router.callback_query(OrderState.confirming, F.data == "order_confirm")
async def confirm_and_submit_order(callback: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    """Persist order to DB and alert admin."""
    data = await state.get_data()
    user = await get_or_create_user(session, callback.from_user.id)

    order, items = await create_order(
        session=session,
        user_id=user.id,
        phone=data["phone"],
        address=data["address"],
        comment=data.get("comment")
    )

    await state.clear()

    if not order:
        await callback.message.edit_text("❌ Buyurtma yaratishda xatolik yuz berdi. Savatchangiz bo‘sh bo‘lishi mumkin.")
        await callback.answer()
        return

    active_btns = await get_active_reply_buttons(session)
    await callback.message.delete()
    await callback.message.answer(
        "Buyurtmangiz qabul qilindi! Adminimiz sizga tez orada bog'lanishadi.",
        reply_markup=main_menu_keyboard(active_btns)
    )

    # Dispatch notification to all configured admin IDs simultaneously
    admin_text = format_order_admin_view(order)
    admin_kb = admin_order_inline_keyboard(order.id)

    for admin_id in config.ADMIN_IDS:
        try:
            await callback.bot.send_message(
                chat_id=admin_id,
                text=admin_text,
                reply_markup=admin_kb
            )
        except Exception as e:
            print(f"Failed to notify admin {admin_id}: {e}")

    await callback.answer()

# --- CUSTOMER ORDER HISTORY ---
@router.message(F.text == "📦 Buyurtmalarim")
async def show_user_orders(message: Message, session: AsyncSession) -> None:
    """List customer previous orders."""
    user = await get_or_create_user(session, message.from_user.id)
    orders = await get_user_orders(session, user.id)

    if not orders:
        await message.answer("📦 **Sizda hali buyurtmalar mavjud emas.**", parse_mode="Markdown")
        return

    lines = ["📦 **BUYURTMALARIM**\n"]
    builder = []

    for order in orders:
        date_str = order.created_at.strftime("%d.%m.%Y") if order.created_at else ""
        lines.append(
            f"**#{order.id}** — {order.status.upper()}\n"
            f"💰 {format_price(order.total_price)} | 📅 {date_str}\n"
        )
        builder.append([InlineKeyboardButton(text=f"📄 Buyurtma #{order.id} tafsilotlari", callback_data=f"user_order_detail:{order.id}")])

    markup = InlineKeyboardMarkup(inline_keyboard=builder)
    await message.answer("\n".join(lines), reply_markup=markup, parse_mode="Markdown")

@router.callback_query(F.data.startswith("user_order_detail:"))
async def user_order_detail(callback: CallbackQuery, session: AsyncSession) -> None:
    """Show details of a specific user order."""
    order_id = int(callback.data.split(":")[1])
    order = await get_order_by_id(session, order_id)

    if not order:
        await callback.answer("Buyurtma topilmadi.", show_alert=True)
        return

    text = format_order_user_view(order)
    await callback.message.answer(text)
    await callback.answer()

# --- ADMIN STATUS CHANGE CALLBACK ---
@router.callback_query(F.data.startswith("admin_order:"))
async def admin_change_order_status(callback: CallbackQuery, session: AsyncSession) -> None:
    """Handle admin order status buttons."""
    if not config.is_admin(callback.from_user.id):
        await callback.answer("⚠️ Ushbu amal faqat adminlar uchun!", show_alert=True)
        return

    parts = callback.data.split(":")
    new_status = parts[1]
    order_id = int(parts[2])

    order = await update_order_status(session, order_id, new_status)
    if not order:
        await callback.answer("Buyurtma topilmadi.", show_alert=True)
        return

    # Update admin message text
    updated_admin_text = format_order_admin_view(order)
    try:
        await callback.message.edit_text(
            updated_admin_text,
            reply_markup=admin_order_inline_keyboard(order.id)
        )
    except Exception:
        pass

    # Customer notification messages based on status
    customer_messages = {
        "confirmed": "✅ Buyurtmangiz qabul qilindi.",
        "shipping": "🚚 Buyurtmangiz yetkazishga berildi.",
        "delivered": "✅ Buyurtmangiz yetkazildi.",
        "cancelled": "❌ Buyurtmangiz bekor qilindi."
    }

    notify_text = customer_messages.get(new_status, f"Buyurtmangiz holati o‘zgardi: {new_status}")

    if order.user and order.user.telegram_id:
        try:
            await callback.bot.send_message(
                chat_id=order.user.telegram_id,
                text=f"📦 **Buyurtma #{order.id} update:**\n\n{notify_text}",
                parse_mode="Markdown"
            )
        except Exception as e:
            print(f"Failed to notify user {order.user.telegram_id}: {e}")

    await callback.answer(f"Status '{new_status}' ga o'zgartirildi.")
