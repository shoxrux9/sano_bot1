from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from database.crud import search_books
from states.states import SearchState
from keyboards.reply import cancel_keyboard, main_menu_keyboard
from keyboards.inline import books_list_inline_keyboard

router = Router()

@router.message(F.text == "🔎 Kitob qidirish")
async def start_search(message: Message, state: FSMContext) -> None:
    """Prompt user for book title or author query."""
    await state.set_state(SearchState.waiting_for_query)
    await message.answer(
        "🔎 **Kitob nomi yoki muallifini yozing:**",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )

@router.message(SearchState.waiting_for_query, F.text == "⬅️ Bekor qilish")
async def cancel_search(message: Message, state: FSMContext) -> None:
    """Cancel search state."""
    await state.clear()
    await message.answer("Qidiruv bekor qilindi.", reply_markup=main_menu_keyboard())

@router.message(SearchState.waiting_for_query)
async def process_search_query(message: Message, state: FSMContext, session: AsyncSession) -> None:
    """Execute database search by title or author."""
    query_str = message.text.strip()
    await state.clear()

    if len(query_str) < 2:
        await message.answer(
            "⚠️ Qidiruv iborasi juda kalta. Kamida 2 ta harf kiriting.",
            reply_markup=main_menu_keyboard()
        )
        return

    books = await search_books(session, query_str)

    if not books:
        await message.answer(
            f"❌ **Hech narsa topilmadi.**\n\n"
            f"\"{query_str}\" bo‘yicha hech qanday kitob topilmadi. "
            f"Boshqa kitob nomi yoki muallif nomini yozib ko‘ring.",
            reply_markup=main_menu_keyboard(),
            parse_mode="Markdown"
        )
    else:
        await message.answer(
            f"🔎 **Qidiruv natijalari (\"{query_str}\" bo‘yicha {len(books)} ta kitob):**",
            reply_markup=books_list_inline_keyboard(books, back_callback="menu_main"),
            reply_markup_main=main_menu_keyboard(),
            parse_mode="Markdown"
        )
