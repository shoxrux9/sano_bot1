import logging
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

import config
from database.crud import (
    get_categories,
    get_category_by_id,
    create_category,
    delete_category,
    get_books_by_category,
    get_book_by_id,
    create_book,
    update_book,
    delete_book,
    get_admin_stats,
    get_all_menus,
    get_menu_by_id,
    toggle_menu_status,
    update_menu_content,
    get_all_buttons,
    get_button_by_id,
    toggle_button_status,
    update_button_title,
    update_button_reply_text,
    create_custom_button,
    get_active_reply_buttons,
    get_all_orders,
    get_order_by_id,
    update_order_status
)
from states.states import (
    AdminAddBookState,
    AdminEditBookState,
    AdminCategoryState,
    AdminMenuEditState,
    AdminButtonEditState
)
from keyboards.inline import (
    admin_main_inline_keyboard,
    admin_confirm_delete_keyboard,
    admin_confirm_delete_category_keyboard,
    admin_menus_list_keyboard,
    admin_single_menu_keyboard,
    admin_buttons_list_keyboard,
    admin_single_button_keyboard,
    admin_order_inline_keyboard
)
from keyboards.reply import cancel_keyboard, main_menu_keyboard
from utils.helpers import format_price, format_order_status, format_order_admin_view

logger = logging.getLogger(__name__)

router = Router()

# Security Guard: Apply router-level admin filters for messages and callback queries
router.message.filter(lambda message: config.is_admin(message.from_user.id))
router.callback_query.filter(lambda callback: config.is_admin(callback.from_user.id))

# --- MAIN ADMIN MENU ---
@router.message(Command("admin"))
async def cmd_admin(message: Message) -> None:
    """Entrypoint for admin panel."""
    admin_text = (
        "👑 **ADMIN PANEL**\n\n"
        "SANO BOOKS boshqaruv paneliga xush kelibsiz.\n"
        "Quyidagi tugmalardan birini tanlang:"
    )
    await message.answer(admin_text, reply_markup=admin_main_inline_keyboard(), parse_mode="Markdown")

@router.callback_query(F.data == "admin_main")
async def cb_admin_main(callback: CallbackQuery, state: FSMContext) -> None:
    """Return to admin panel main menu."""
    await state.clear()
    admin_text = (
        "👑 **ADMIN PANEL**\n\n"
        "Quyidagi tugmalardan birini tanlang:"
    )
    if callback.message.photo:
        await callback.message.delete()
        await callback.message.answer(admin_text, reply_markup=admin_main_inline_keyboard(), parse_mode="Markdown")
    else:
        await callback.message.edit_text(admin_text, reply_markup=admin_main_inline_keyboard(), parse_mode="Markdown")
    await callback.answer()

# --- 1. BOOKS MANAGEMENT ---
@router.callback_query(F.data == "admin_books_list")
async def admin_books_list(callback: CallbackQuery, session: AsyncSession) -> None:
    """List all books grouped by category."""
    categories = await get_categories(session)
    builder = []
    for cat in categories:
        books = await get_books_by_category(session, cat.id)
        for b in books:
            builder.append([InlineKeyboardButton(text=f"📕 {b.title} ({format_price(b.price)})", callback_data=f"book_view:{b.id}")])

    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")])
    kb = InlineKeyboardMarkup(inline_keyboard=builder)

    await callback.message.edit_text("📚 **Barcha kitoblar ro‘yxati:**", reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

# --- ADD BOOK FSM ---
@router.callback_query(F.data == "admin_book_add")
async def start_add_book(callback: CallbackQuery, state: FSMContext) -> None:
    """Start 10-step interactive FSM to add a new book."""
    await state.set_state(AdminAddBookState.waiting_for_title)
    await callback.message.delete()
    await callback.message.answer("📕 **1/10. Kitob nomini kiriting:**", reply_markup=cancel_keyboard(), parse_mode="Markdown")
    await callback.answer()

@router.message(AdminAddBookState.waiting_for_title, F.text == "⬅️ Bekor qilish")
@router.message(AdminAddBookState.waiting_for_author, F.text == "⬅️ Bekor qilish")
@router.message(AdminAddBookState.waiting_for_description, F.text == "⬅️ Bekor qilish")
@router.message(AdminAddBookState.waiting_for_price, F.text == "⬅️ Bekor qilish")
@router.message(AdminAddBookState.waiting_for_pages, F.text == "⬅️ Bekor qilish")
@router.message(AdminAddBookState.waiting_for_format, F.text == "⬅️ Bekor qilish")
@router.message(AdminAddBookState.waiting_for_image, F.text == "⬅️ Bekor qilish")
@router.message(AdminEditBookState.waiting_for_value, F.text == "⬅️ Bekor qilish")
async def cancel_add_book(message: Message, state: FSMContext, session: AsyncSession) -> None:
    """Cancel book adding or editing operation."""
    await state.clear()
    active_btns = await get_active_reply_buttons(session)
    await message.answer("Amal bekor qilindi.", reply_markup=main_menu_keyboard(active_btns))

@router.message(AdminAddBookState.waiting_for_title)
async def process_add_title(message: Message, state: FSMContext) -> None:
    await state.update_data(title=message.text.strip())
    await state.set_state(AdminAddBookState.waiting_for_author)
    await message.answer("✍️ **2/10. Muallif nomini kiriting:**", reply_markup=cancel_keyboard(), parse_mode="Markdown")

@router.message(AdminAddBookState.waiting_for_author)
async def process_add_author(message: Message, state: FSMContext, session: AsyncSession) -> None:
    await state.update_data(author=message.text.strip())
    
    categories = await get_categories(session)
    if not categories:
        active_btns = await get_active_reply_buttons(session)
        await message.answer("📂 Avval kamida bitta kategoriya yarating!", reply_markup=main_menu_keyboard(active_btns))
        await state.clear()
        return

    builder = []
    for cat in categories:
        builder.append([InlineKeyboardButton(text=cat.name, callback_data=f"admin_sel_cat:{cat.id}")])
    kb = InlineKeyboardMarkup(inline_keyboard=builder)

    await state.set_state(AdminAddBookState.waiting_for_category)
    await message.answer("📂 **3/10. Kategoriyani tanlang:**", reply_markup=kb, parse_mode="Markdown")

@router.callback_query(AdminAddBookState.waiting_for_category, F.data.startswith("admin_sel_cat:"))
async def process_add_category(callback: CallbackQuery, state: FSMContext) -> None:
    cat_id = int(callback.data.split(":")[1])
    await state.update_data(category_id=cat_id)
    await state.set_state(AdminAddBookState.waiting_for_description)
    await callback.message.delete()
    await callback.message.answer("📝 **4/10. Kitob haqida tavsif yozing:**", reply_markup=cancel_keyboard(), parse_mode="Markdown")
    await callback.answer()

@router.message(AdminAddBookState.waiting_for_description)
async def process_add_description(message: Message, state: FSMContext) -> None:
    await state.update_data(description=message.text.strip())
    await state.set_state(AdminAddBookState.waiting_for_price)
    await message.answer("💰 **5/10. Kitob narxini kiriting (masalan: 15000):**", reply_markup=cancel_keyboard(), parse_mode="Markdown")

@router.message(AdminAddBookState.waiting_for_price)
async def process_add_price(message: Message, state: FSMContext) -> None:
    try:
        price = float(message.text.strip().replace(" ", ""))
        await state.update_data(price=price)
        await state.set_state(AdminAddBookState.waiting_for_pages)
        await message.answer("📄 **6/10. Betlar sonini kiriting (masalan: 160):**", reply_markup=cancel_keyboard(), parse_mode="Markdown")
    except ValueError:
        await message.answer("⚠️ Iltimos, narxni faqat raqam bilan kiriting (masalan: 15000):", reply_markup=cancel_keyboard())

@router.message(AdminAddBookState.waiting_for_pages)
async def process_add_pages(message: Message, state: FSMContext) -> None:
    if not message.text.isdigit():
        await message.answer("⚠️ Betlar soni faqat raqam bo‘lishi kerak (masalan: 160):", reply_markup=cancel_keyboard())
        return
    await state.update_data(pages=int(message.text))
    await state.set_state(AdminAddBookState.waiting_for_format)
    await message.answer("📐 **7/10. Kitob formatini kiriting (masalan: 135×210 mm):**", reply_markup=cancel_keyboard(), parse_mode="Markdown")

@router.message(AdminAddBookState.waiting_for_format)
async def process_add_format(message: Message, state: FSMContext) -> None:
    await state.update_data(format=message.text.strip())
    await state.set_state(AdminAddBookState.waiting_for_image)
    await message.answer(
        "🖼 **8/10. Kitob muqovasi rasmini yuboring:**\n\n"
        "(Rasm yo‘q bo‘lsa **-** belgisini yuboring)",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )

@router.message(AdminAddBookState.waiting_for_image, F.photo)
@router.message(AdminAddBookState.waiting_for_image, F.text)
async def process_add_image(message: Message, state: FSMContext) -> None:
    if message.photo:
        file_id = message.photo[-1].file_id
    else:
        file_id = None

    await state.update_data(image_file_id=file_id)
    await state.set_state(AdminAddBookState.waiting_for_bestseller)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔥 Ha (Bestseller)", callback_data="add_bs:yes"),
            InlineKeyboardButton(text="Yo‘q", callback_data="add_bs:no")
        ]
    ])
    await message.answer("🔥 **9/10. Ushbu kitob Bestseller statusiga ega bormi?**", reply_markup=kb, parse_mode="Markdown")

@router.callback_query(AdminAddBookState.waiting_for_bestseller, F.data.startswith("add_bs:"))
async def process_add_bestseller(callback: CallbackQuery, state: FSMContext) -> None:
    is_bs = callback.data.split(":")[1] == "yes"
    await state.update_data(is_bestseller=is_bs)
    await state.set_state(AdminAddBookState.waiting_for_new)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🆕 Ha (Yangi kitob)", callback_data="add_new:yes"),
            InlineKeyboardButton(text="Yo‘q", callback_data="add_new:no")
        ]
    ])
    await callback.message.edit_text("🆕 **10/10. Yangi kitoblar bo‘limiga kiritilsinmi?**", reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(AdminAddBookState.waiting_for_new, F.data.startswith("add_new:"))
async def process_add_new_and_save(callback: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    is_new_val = callback.data.split(":")[1] == "yes"
    data = await state.get_data()
    await state.clear()

    try:
        book = await create_book(
            session=session,
            title=data["title"],
            author=data["author"],
            category_id=data["category_id"],
            description=data["description"],
            price=data["price"],
            pages=data["pages"],
            format=data["format"],
            image_file_id=data.get("image_file_id"),
            is_bestseller=data.get("is_bestseller", False),
            is_new=is_new_val
        )
        logger.info(f"Book created by admin {callback.from_user.id}: #{book.id} - {book.title}")
        active_btns = await get_active_reply_buttons(session)

        await callback.message.delete()
        await callback.message.answer(
            f"✅ **Kitob muvaffaqiyatli saqlandi!**\n\n"
            f"📕 {book.title} ({format_price(book.price)})",
            reply_markup=main_menu_keyboard(active_btns),
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Error creating book: {e}", exc_info=True)
        await callback.message.answer("❌ Kitobni saqlashda xatolik yuz berdi.")
    await callback.answer()

# --- EDIT BOOK FSM ---
@router.callback_query(F.data == "admin_book_edit_select")
async def select_book_to_edit(callback: CallbackQuery, session: AsyncSession) -> None:
    categories = await get_categories(session)
    builder = []
    for cat in categories:
        books = await get_books_by_category(session, cat.id)
        for b in books:
            builder.append([InlineKeyboardButton(text=f"✏️ {b.title}", callback_data=f"admin_edit_book:{b.id}")])

    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")])
    kb = InlineKeyboardMarkup(inline_keyboard=builder)

    await callback.message.edit_text("✏️ **Tahrirlash uchun kitobni tanlang:**", reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_edit_book:"))
async def choose_edit_field(callback: CallbackQuery, session: AsyncSession) -> None:
    book_id = int(callback.data.split(":")[1])
    book = await get_book_by_id(session, book_id)

    if not book:
        await callback.answer("Kitob topilmadi.", show_alert=True)
        return

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="💰 Narxni o‘zgartirish", callback_data=f"edit_field:price:{book.id}"),
            InlineKeyboardButton(text="🖼 Rasmni yangilash", callback_data=f"edit_field:photo:{book.id}")
        ],
        [
            InlineKeyboardButton(text="📝 Tavsifni tahrirlash", callback_data=f"edit_field:desc:{book.id}"),
            InlineKeyboardButton(text="📕 Nomi", callback_data=f"edit_field:title:{book.id}")
        ],
        [
            InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_book_edit_select")
        ]
    ])

    text = f"✏️ **{book.title}** kitobining qaysi ma'lumotini o‘zgartirmoqchisiz?\n\nHozirgi narxi: {format_price(book.price)}"
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("edit_field:"))
async def prompt_edit_value(callback: CallbackQuery, state: FSMContext) -> None:
    parts = callback.data.split(":")
    field = parts[1]
    book_id = int(parts[2])

    await state.update_data(edit_book_id=book_id, edit_field=field)
    await state.set_state(AdminEditBookState.waiting_for_value)

    prompts = {
        "price": "💰 **Yangi narxni kiriting (masalan: 18000):**",
        "photo": "🖼 **Yangi kitob rasmini yuboring:**",
        "desc": "📝 **Yangi kitob tavsifini yozing:**",
        "title": "📕 **Yangi kitob nomini kiriting:**"
    }

    await callback.message.delete()
    await callback.message.answer(prompts.get(field, "Yangi qiymatni kiriting:"), reply_markup=cancel_keyboard(), parse_mode="Markdown")
    await callback.answer()

@router.message(AdminEditBookState.waiting_for_value, F.photo)
@router.message(AdminEditBookState.waiting_for_value, F.text)
async def process_edit_save(message: Message, state: FSMContext, session: AsyncSession) -> None:
    data = await state.get_data()
    book_id = data["edit_book_id"]
    field = data["edit_field"]
    active_btns = await get_active_reply_buttons(session)

    kwargs = {}
    if field == "price":
        try:
            kwargs["price"] = float(message.text.strip().replace(" ", ""))
        except ValueError:
            await message.answer("⚠️ Iltimos, narxni faqat raqam bilan kiriting:", reply_markup=cancel_keyboard())
            return
    elif field == "photo":
        if message.photo:
            kwargs["image_file_id"] = message.photo[-1].file_id
    elif field == "desc":
        kwargs["description"] = message.text.strip()
    elif field == "title":
        kwargs["title"] = message.text.strip()

    await state.clear()
    if kwargs:
        book = await update_book(session, book_id, **kwargs)
        title = book.title if book else "Kitob"
        await message.answer(f"✅ **{title}** muvaffaqiyatli tahrirlandi!", reply_markup=main_menu_keyboard(active_btns), parse_mode="Markdown")
    else:
        await message.answer("Tahrirlashda o'zgarish bo'lmadi.", reply_markup=main_menu_keyboard(active_btns))

# --- DELETE BOOK (WITH CONFIRMATION MODAL) ---
@router.callback_query(F.data == "admin_book_delete_select")
async def select_book_to_delete(callback: CallbackQuery, session: AsyncSession) -> None:
    categories = await get_categories(session)
    builder = []
    for cat in categories:
        books = await get_books_by_category(session, cat.id)
        for b in books:
            builder.append([InlineKeyboardButton(text=f"🗑 {b.title}", callback_data=f"admin_del_ask:{b.id}")])

    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")])
    kb = InlineKeyboardMarkup(inline_keyboard=builder)

    await callback.message.edit_text("🗑 **O‘chirish uchun kitobni tanlang:**", reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_del_ask:"))
async def ask_delete_confirmation(callback: CallbackQuery, session: AsyncSession) -> None:
    book_id = int(callback.data.split(":")[1])
    book = await get_book_by_id(session, book_id)

    if not book:
        await callback.answer("Kitob topilmadi.", show_alert=True)
        return

    text = f"⚠️ **Haqiqatan ham ushbu kitobni o'chirmoqchimisiz?**\n\n📕 **{book.title}** ({book.author})"
    await callback.message.edit_text(text, reply_markup=admin_confirm_delete_keyboard(book.id), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data == "admin_book_delete_cancel")
async def cancel_delete_book(callback: CallbackQuery) -> None:
    await callback.message.edit_text("O‘chirish bekor qilindi.", reply_markup=admin_main_inline_keyboard())
    await callback.answer()

@router.callback_query(F.data.startswith("admin_book_delete_confirm:"))
async def confirm_delete_book(callback: CallbackQuery, session: AsyncSession) -> None:
    book_id = int(callback.data.split(":")[1])
    success = await delete_book(session, book_id)

    if success:
        logger.info(f"Book #{book_id} deleted by admin {callback.from_user.id}")
        await callback.message.edit_text("✅ Kitob bazadan o‘chirildi.", reply_markup=admin_main_inline_keyboard())
    else:
        await callback.message.edit_text("❌ Kitobni o‘chirishda xatolik.", reply_markup=admin_main_inline_keyboard())
    await callback.answer()

# --- 2. CATEGORIES MANAGEMENT ---
@router.callback_query(F.data == "admin_categories")
async def admin_manage_categories(callback: CallbackQuery, session: AsyncSession) -> None:
    categories = await get_categories(session)
    text = "📂 **KATEGORIYALAR BOSH QARUVI:**\n\n"
    builder = []

    for cat in categories:
        text += f"• {cat.name}\n"

    builder.append([InlineKeyboardButton(text="➕ Yangi kategoriya qo‘shish", callback_data="admin_add_cat")])
    if categories:
        builder.append([InlineKeyboardButton(text="🗑 Kategoriyani o'chirish", callback_data="admin_cat_delete_select")])
    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")])

    await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=builder), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data == "admin_add_cat")
async def start_add_category(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminCategoryState.waiting_for_category_name)
    await callback.message.delete()
    await callback.message.answer("📂 **Yangi kategoriya nomini kiriting:**", reply_markup=cancel_keyboard(), parse_mode="Markdown")
    await callback.answer()

@router.message(AdminCategoryState.waiting_for_category_name, F.text == "⬅️ Bekor qilish")
async def cancel_add_category(message: Message, state: FSMContext, session: AsyncSession) -> None:
    await state.clear()
    active_btns = await get_active_reply_buttons(session)
    await message.answer("Kategoriya qo‘shish bekor qilindi.", reply_markup=main_menu_keyboard(active_btns))

@router.message(AdminCategoryState.waiting_for_category_name)
async def process_add_category_name(message: Message, state: FSMContext, session: AsyncSession) -> None:
    cat_name = message.text.strip()
    await state.clear()

    await create_category(session, cat_name)
    logger.info(f"Category '{cat_name}' created by admin {message.from_user.id}")
    active_btns = await get_active_reply_buttons(session)
    await message.answer(f"✅ Kategoriya **\"{cat_name}\"** yaratildi!", reply_markup=main_menu_keyboard(active_btns), parse_mode="Markdown")

@router.callback_query(F.data == "admin_cat_delete_select")
async def select_category_to_delete(callback: CallbackQuery, session: AsyncSession) -> None:
    categories = await get_categories(session)
    builder = []
    for cat in categories:
        builder.append([InlineKeyboardButton(text=f"🗑 {cat.name}", callback_data=f"admin_cat_del_ask:{cat.id}")])

    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_categories")])
    kb = InlineKeyboardMarkup(inline_keyboard=builder)

    await callback.message.edit_text("🗑 **O‘chirish uchun kategoriyani tanlang:**", reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_cat_del_ask:"))
async def ask_delete_category_confirmation(callback: CallbackQuery, session: AsyncSession) -> None:
    cat_id = int(callback.data.split(":")[1])
    cat = await get_category_by_id(session, cat_id)

    if not cat:
        await callback.answer("Kategoriya topilmadi.", show_alert=True)
        return

    text = f"⚠️ **Haqiqatan ham ushbu kategoriyani o'chirmoqchimisiz?**\n\n📂 **{cat.name}**\n(Eslatma: Ichidagi kitoblar ham o'chishi mumkin)"
    await callback.message.edit_text(text, reply_markup=admin_confirm_delete_category_keyboard(cat.id), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_cat_delete_confirm:"))
async def confirm_delete_category(callback: CallbackQuery, session: AsyncSession) -> None:
    cat_id = int(callback.data.split(":")[1])
    success = await delete_category(session, cat_id)

    if success:
        logger.info(f"Category #{cat_id} deleted by admin {callback.from_user.id}")
        await callback.message.edit_text("✅ Kategoriya muvaffaqiyatli o‘chirildi.", reply_markup=admin_main_inline_keyboard())
    else:
        await callback.message.edit_text("❌ Kategoriyani o‘chirishda xatolik.", reply_markup=admin_main_inline_keyboard())
    await callback.answer()

# --- 3. ORDERS MANAGEMENT ---
@router.callback_query(F.data == "admin_orders_list")
async def admin_orders_list(callback: CallbackQuery, session: AsyncSession) -> None:
    """List recent orders in admin panel."""
    orders = await get_all_orders(session, limit=30)
    if not orders:
        kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")]])
        await callback.message.edit_text("📦 **Hozircha buyurtmalar mavjud emas.**", reply_markup=kb, parse_mode="Markdown")
        await callback.answer()
        return

    lines = ["📦 **BARCHA BUYURTMALAR (so'nggi 30 ta):**\n"]
    builder = []
    for o in orders:
        status_label = format_order_status(o.status)
        lines.append(f"• **#{o.id}** — {status_label} | {format_price(o.total_price)}")
        builder.append([InlineKeyboardButton(text=f"📋 Buyurtma #{o.id} [{status_label}]", callback_data=f"admin_order_view:{o.id}")])

    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")])
    kb = InlineKeyboardMarkup(inline_keyboard=builder)

    await callback.message.edit_text("\n".join(lines), reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_order_view:"))
async def admin_order_view(callback: CallbackQuery, session: AsyncSession) -> None:
    """View details of an order from admin panel."""
    order_id = int(callback.data.split(":")[1])
    order = await get_order_by_id(session, order_id)

    if not order:
        await callback.answer("Buyurtma topilmadi.", show_alert=True)
        return

    text = format_order_admin_view(order)
    kb = admin_order_inline_keyboard(order.id)

    await callback.message.edit_text(text, reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

# --- 4. STATISTICS ---
@router.callback_query(F.data == "admin_stats")
async def cb_admin_stats(callback: CallbackQuery, session: AsyncSession) -> None:
    """Render comprehensive admin statistics report."""
    stats = await get_admin_stats(session)

    status_str = "\n".join([f"• {k.capitalize()}: {v} ta" for k, v in stats["status_counts"].items()]) if stats["status_counts"] else "Ma'lumot yo'q"

    stats_text = (
        "📊 **STATISTIKA**\n\n"
        f"📅 **Bugungi buyurtmalar:** {stats['today_orders']} ta\n"
        f"💰 **Bugungi tushum:** {format_price(stats['today_revenue'])}\n\n"
        f"🗓 **So‘nggi 7 kun:** {stats['count_7d']} ta buyurtma ({format_price(stats['revenue_7d'])})\n"
        f"🗓 **So‘nggi 30 kun:** {stats['count_30d']} ta buyurtma ({format_price(stats['revenue_30d'])})\n\n"
        f"📦 **Jami buyurtmalar:** {stats['total_orders']} ta\n"
        f"📚 **Jami sotilgan kitoblar:** {stats['total_books_sold']} dona\n\n"
        f"🔥 **Eng ko‘p sotilgan kitob:**\n{stats['bestseller_title']}\n\n"
        f"💰 **Umumiy tushum:**\n{format_price(stats['total_revenue'])}\n\n"
        f"📌 **Holatlar bo‘yicha:**\n{status_str}"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")]])
    await callback.message.edit_text(stats_text, reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

# --- 5. DYNAMIC MENU MANAGEMENT ---
@router.callback_query(F.data == "admin_menus")
async def admin_menus_list(callback: CallbackQuery, session: AsyncSession) -> None:
    menus = await get_all_menus(session)
    text = (
        "⚙️ **MENULARNI BOSH QARISH**\n\n"
        "Tugmani yoqish/o'chirish yoki matnini tahrirlash uchun tanlang:"
    )
    await callback.message.edit_text(text, reply_markup=admin_menus_list_keyboard(menus), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_menu_manage:"))
async def admin_menu_manage(callback: CallbackQuery, session: AsyncSession) -> None:
    menu_id = int(callback.data.split(":")[1])
    menu = await get_menu_by_id(session, menu_id)

    if not menu:
        await callback.answer("Menu topilmadi.", show_alert=True)
        return

    status_str = "✅ Yoqilgan" if menu.is_active else "❌ O'chirilgan"
    text = (
        f"⚙️ **MENU: {menu.title}**\n\n"
        f"📌 Holati: **{status_str}**\n\n"
        f"📝 **Hozirgi matn:**\n{menu.content}"
    )

    await callback.message.edit_text(text, reply_markup=admin_single_menu_keyboard(menu), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_menu_toggle:"))
async def admin_menu_toggle(callback: CallbackQuery, session: AsyncSession) -> None:
    menu_id = int(callback.data.split(":")[1])
    menu = await toggle_menu_status(session, menu_id)

    if not menu:
        await callback.answer("Menu topilmadi.", show_alert=True)
        return

    status_str = "✅ Yoqilgan" if menu.is_active else "❌ O'chirilgan"
    text = (
        f"⚙️ **MENU: {menu.title}**\n\n"
        f"📌 Holati: **{status_str}**\n\n"
        f"📝 **Hozirgi matn:**\n{menu.content}"
    )

    await callback.message.edit_text(text, reply_markup=admin_single_menu_keyboard(menu), parse_mode="Markdown")
    await callback.answer(f"Status '{status_str}' ga o'zgartirildi.")

@router.callback_query(F.data.startswith("admin_menu_edit_text:"))
async def start_edit_menu_content(callback: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    menu_id = int(callback.data.split(":")[1])
    menu = await get_menu_by_id(session, menu_id)

    if not menu:
        await callback.answer("Menu topilmadi.", show_alert=True)
        return

    await state.update_data(edit_menu_id=menu.id)
    await state.set_state(AdminMenuEditState.waiting_for_content)

    await callback.message.delete()
    await callback.message.answer(
        f"✏️ **\"{menu.title}\" bo'limi uchun yangi matnni kiriting:**",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.message(AdminMenuEditState.waiting_for_content, F.text == "⬅️ Bekor qilish")
async def cancel_menu_edit(message: Message, state: FSMContext, session: AsyncSession) -> None:
    await state.clear()
    active_btns = await get_active_reply_buttons(session)
    await message.answer("Menu tahrirlash bekor qilindi.", reply_markup=main_menu_keyboard(active_btns))

@router.message(AdminMenuEditState.waiting_for_content)
async def process_edit_menu_content(message: Message, state: FSMContext, session: AsyncSession) -> None:
    data = await state.get_data()
    menu_id = data["edit_menu_id"]
    new_content = message.text.strip()
    await state.clear()

    menu = await update_menu_content(session, menu_id, new_content)
    title = menu.title if menu else "Menu"
    active_btns = await get_active_reply_buttons(session)

    await message.answer(
        f"✅ **\"{title}\" matni muvaffaqiyatli yangilandi!**",
        reply_markup=main_menu_keyboard(active_btns),
        parse_mode="Markdown"
    )

# --- 6. UNIVERSAL DYNAMIC BUTTONS MANAGEMENT ---
@router.callback_query(F.data == "admin_buttons_list")
async def admin_buttons_list(callback: CallbackQuery, session: AsyncSession) -> None:
    buttons = await get_all_buttons(session)
    text = (
        "🎛️ **BARCHA TUGMALAR BOSH QARUVI**\n\n"
        "Tugmani yoqish/o'chirish, nomini yoki javob matnini tahrirlash uchun tanlang:"
    )
    await callback.message.edit_text(text, reply_markup=admin_buttons_list_keyboard(buttons), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_btn_manage:"))
async def admin_btn_manage(callback: CallbackQuery, session: AsyncSession) -> None:
    btn_id = int(callback.data.split(":")[1])
    btn = await get_button_by_id(session, btn_id)

    if not btn:
        await callback.answer("Tugma topilmadi.", show_alert=True)
        return

    status_str = "🟢 Yoqilgan" if btn.is_active else "🔴 O'chirilgan"
    reply_preview = btn.reply_text or "(Asosiy funksiya / Tizim tugmasi)"

    text = (
        f"🎛️ **TUGMA: {btn.title}**\n\n"
        f"🔑 Key: `{btn.button_key}`\n"
        f"📌 Holati: **{status_str}**\n\n"
        f"📝 **Javob matni:**\n{reply_preview}"
    )

    await callback.message.edit_text(text, reply_markup=admin_single_button_keyboard(btn), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("admin_btn_toggle:"))
async def admin_btn_toggle(callback: CallbackQuery, session: AsyncSession) -> None:
    btn_id = int(callback.data.split(":")[1])
    btn = await toggle_button_status(session, btn_id)

    if not btn:
        await callback.answer("Tugma topilmadi.", show_alert=True)
        return

    status_str = "🟢 Yoqilgan" if btn.is_active else "🔴 O'chirilgan"
    reply_preview = btn.reply_text or "(Asosiy funksiya / Tizim tugmasi)"

    text = (
        f"🎛️ **TUGMA: {btn.title}**\n\n"
        f"🔑 Key: `{btn.button_key}`\n"
        f"📌 Holati: **{status_str}**\n\n"
        f"📝 **Javob matni:**\n{reply_preview}"
    )

    await callback.message.edit_text(text, reply_markup=admin_single_button_keyboard(btn), parse_mode="Markdown")
    await callback.answer(f"Tugma holati '{status_str}' ga o'zgartirildi.")

@router.callback_query(F.data.startswith("admin_btn_edit_title:"))
async def admin_btn_edit_title(callback: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    btn_id = int(callback.data.split(":")[1])
    btn = await get_button_by_id(session, btn_id)

    if not btn:
        await callback.answer("Tugma topilmadi.", show_alert=True)
        return

    await state.update_data(edit_btn_id=btn.id)
    await state.set_state(AdminButtonEditState.waiting_for_title)

    await callback.message.delete()
    await callback.message.answer(
        f"✏️ **\"{btn.title}\" tugmasi uchun yangi nom kiriting:**",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.message(AdminButtonEditState.waiting_for_title, F.text == "⬅️ Bekor qilish")
@router.message(AdminButtonEditState.waiting_for_reply_text, F.text == "⬅️ Bekor qilish")
@router.message(AdminButtonEditState.waiting_for_custom_title, F.text == "⬅️ Bekor qilish")
@router.message(AdminButtonEditState.waiting_for_custom_text, F.text == "⬅️ Bekor qilish")
async def cancel_button_edit(message: Message, state: FSMContext, session: AsyncSession) -> None:
    await state.clear()
    active_btns = await get_active_reply_buttons(session)
    await message.answer("Tugma tahrirlash bekor qilindi.", reply_markup=main_menu_keyboard(active_btns))

@router.message(AdminButtonEditState.waiting_for_title)
async def process_edit_button_title(message: Message, state: FSMContext, session: AsyncSession) -> None:
    data = await state.get_data()
    btn_id = data["edit_btn_id"]
    new_title = message.text.strip()
    await state.clear()

    btn = await update_button_title(session, btn_id, new_title)
    title = btn.title if btn else "Tugma"
    active_btns = await get_active_reply_buttons(session)

    await message.answer(
        f"✅ **Tugma nomi \"{title}\" ga muvaffaqiyatli o'zgartirildi!**",
        reply_markup=main_menu_keyboard(active_btns),
        parse_mode="Markdown"
    )

@router.callback_query(F.data.startswith("admin_btn_edit_text:"))
async def admin_btn_edit_text(callback: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    btn_id = int(callback.data.split(":")[1])
    btn = await get_button_by_id(session, btn_id)

    if not btn:
        await callback.answer("Tugma topilmadi.", show_alert=True)
        return

    await state.update_data(edit_btn_id=btn.id)
    await state.set_state(AdminButtonEditState.waiting_for_reply_text)

    await callback.message.delete()
    await callback.message.answer(
        f"📝 **\"{btn.title}\" tugmasi bosilganda ko'rsatiladigan yangi javob matnini kiriting:**",
        reply_markup=cancel_keyboard(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.message(AdminButtonEditState.waiting_for_reply_text)
async def process_edit_button_reply_text(message: Message, state: FSMContext, session: AsyncSession) -> None:
    data = await state.get_data()
    btn_id = data["edit_btn_id"]
    new_reply_text = message.text.strip()
    await state.clear()

    btn = await update_button_reply_text(session, btn_id, new_reply_text)
    title = btn.title if btn else "Tugma"
    active_btns = await get_active_reply_buttons(session)

    await message.answer(
        f"✅ **\"{title}\" javob matni muvaffaqiyatli saqlandi!**",
        reply_markup=main_menu_keyboard(active_btns),
        parse_mode="Markdown"
    )

@router.callback_query(F.data == "admin_btn_add_custom")
async def start_add_custom_button(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminButtonEditState.waiting_for_custom_title)
    await callback.message.delete()
    await callback.message.answer("➕ **Yangi custom tugma nomini kiriting (masalan: 🚚 Aktsiyalar):**", reply_markup=cancel_keyboard(), parse_mode="Markdown")
    await callback.answer()

@router.message(AdminButtonEditState.waiting_for_custom_title)
async def process_custom_title(message: Message, state: FSMContext) -> None:
    title = message.text.strip()
    await state.update_data(custom_title=title)
    await state.set_state(AdminButtonEditState.waiting_for_custom_text)
    await message.answer(f"📝 **\"{title}\" tugmasi bosilganda ko'rsatiladigan matnni kiriting:**", reply_markup=cancel_keyboard(), parse_mode="Markdown")

@router.message(AdminButtonEditState.waiting_for_custom_text)
async def process_custom_text(message: Message, state: FSMContext, session: AsyncSession) -> None:
    data = await state.get_data()
    title = data["custom_title"]
    reply_text = message.text.strip()
    await state.clear()

    btn = await create_custom_button(session, title, reply_text)
    active_btns = await get_active_reply_buttons(session)

    await message.answer(
        f"✅ **Yangi tugma \"{btn.title}\" muvaffaqiyatli qo'shildi!**",
        reply_markup=main_menu_keyboard(active_btns),
        parse_mode="Markdown"
    )
