from typing import Any
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from database.crud import (
    get_or_create_user,
    get_cart,
    add_to_cart,
    update_cart_quantity,
    remove_cart_item,
    clear_cart
)
from keyboards.inline import cart_inline_keyboard
from keyboards.reply import main_menu_keyboard
from utils.helpers import format_price

router = Router()

async def render_cart_message(user_id: int, session: AsyncSession) -> tuple[str, Any]:
    """Helper to generate formatted cart message text and inline keyboard."""
    cart_items = await get_cart(session, user_id)
    if not cart_items:
        return "🛒 **Savatchangiz bo‘sh.**", cart_inline_keyboard([])

    lines = ["🛒 **SAVATCHANGIZ**\n"]
    total_price = 0.0

    for item in cart_items:
        if item.book:
            item_total = item.quantity * item.book.price
            total_price += item_total
            lines.append(
                f"📕 **{item.book.title}**\n"
                f"{item.quantity} dona × {format_price(item.book.price)} = {format_price(item_total)}\n"
            )

    lines.append(f"💰 **Jami:** {format_price(total_price)}")
    return "\n".join(lines), cart_inline_keyboard(cart_items)

@router.message(F.text == "🛒 Savatcham")
async def show_cart_message(message: Message, session: AsyncSession) -> None:
    """Show shopping cart from main menu."""
    telegram_id = message.from_user.id
    user = await get_or_create_user(session, telegram_id)
    text, keyboard = await render_cart_message(user.id, session)
    await message.answer(text, reply_markup=keyboard, parse_mode="Markdown")

@router.callback_query(F.data.startswith("cart_add:"))
async def cb_add_to_cart(callback: CallbackQuery, session: AsyncSession) -> None:
    """Add a book to cart."""
    book_id = int(callback.data.split(":")[1])
    user = await get_or_create_user(session, callback.from_user.id)

    await add_to_cart(session, user_id=user.id, book_id=book_id, quantity=1)
    await callback.answer("✅ Kitob savatchaga qo‘shildi!", show_alert=True)

@router.callback_query(F.data.startswith("cart_inc:"))
async def cb_cart_inc(callback: CallbackQuery, session: AsyncSession) -> None:
    """Increase cart item quantity."""
    cart_item_id = int(callback.data.split(":")[1])
    await update_cart_quantity(session, cart_item_id, delta=1)
    
    user = await get_or_create_user(session, callback.from_user.id)
    text, keyboard = await render_cart_message(user.id, session)

    if callback.message.photo:
        await callback.message.delete()
        await callback.message.answer(text, reply_markup=keyboard, parse_mode="Markdown")
    else:
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("cart_dec:"))
async def cb_cart_dec(callback: CallbackQuery, session: AsyncSession) -> None:
    """Decrease cart item quantity."""
    cart_item_id = int(callback.data.split(":")[1])
    await update_cart_quantity(session, cart_item_id, delta=-1)

    user = await get_or_create_user(session, callback.from_user.id)
    text, keyboard = await render_cart_message(user.id, session)

    if callback.message.photo:
        await callback.message.delete()
        await callback.message.answer(text, reply_markup=keyboard, parse_mode="Markdown")
    else:
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("cart_del:"))
async def cb_cart_del(callback: CallbackQuery, session: AsyncSession) -> None:
    """Delete single item from cart."""
    cart_item_id = int(callback.data.split(":")[1])
    await remove_cart_item(session, cart_item_id)

    user = await get_or_create_user(session, callback.from_user.id)
    text, keyboard = await render_cart_message(user.id, session)

    if callback.message.photo:
        await callback.message.delete()
        await callback.message.answer(text, reply_markup=keyboard, parse_mode="Markdown")
    else:
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode="Markdown")
    await callback.answer("Mahsulot o‘chirildi.")

@router.callback_query(F.data == "cart_clear")
async def cb_cart_clear(callback: CallbackQuery, session: AsyncSession) -> None:
    """Clear all items in cart."""
    user = await get_or_create_user(session, callback.from_user.id)
    await clear_cart(session, user.id)

    text, keyboard = await render_cart_message(user.id, session)
    if callback.message.photo:
        await callback.message.delete()
        await callback.message.answer(text, reply_markup=keyboard, parse_mode="Markdown")
    else:
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode="Markdown")
    await callback.answer("Savatcha tozalandi.")

@router.callback_query(F.data == "noop")
async def cb_noop(callback: CallbackQuery) -> None:
    await callback.answer()
