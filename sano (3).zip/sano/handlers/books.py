from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from database.crud import (
    get_categories,
    get_category_by_id,
    get_books_by_category,
    get_bestseller_books,
    get_new_books,
    get_book_by_id
)
from keyboards.inline import (
    categories_inline_keyboard,
    books_list_inline_keyboard,
    book_card_inline_keyboard,
    book_details_inline_keyboard
)
from utils.helpers import format_book_card

router = Router()

@router.message(F.text == "📚 Kitoblar")
async def show_categories(message: Message, session: AsyncSession) -> None:
    """Show categories inline keyboard."""
    categories = await get_categories(session)
    if not categories:
        await message.answer("📂 Hozircha kategoriyalar mavjud emas.")
        return
    
    await message.answer(
        "📚 **Kategoriyani tanlang:**",
        reply_markup=categories_inline_keyboard(categories),
        parse_mode="Markdown"
    )

@router.callback_query(F.data == "categories_list")
async def cb_categories_list(callback: CallbackQuery, session: AsyncSession) -> None:
    """Callback to return to categories list."""
    categories = await get_categories(session)
    if callback.message.photo:
        await callback.message.delete()
        await callback.message.answer(
            "📚 **Kategoriyani tanlang:**",
            reply_markup=categories_inline_keyboard(categories),
            parse_mode="Markdown"
        )
    else:
        await callback.message.edit_text(
            "📚 **Kategoriyani tanlang:**",
            reply_markup=categories_inline_keyboard(categories),
            parse_mode="Markdown"
        )
    await callback.answer()

@router.message(F.text == "🔥 Bestsellerlar")
async def show_bestsellers(message: Message, session: AsyncSession) -> None:
    """Show bestseller books."""
    books = await get_bestseller_books(session)
    if not books:
        await message.answer("🔥 Hozircha bestseller kitoblar belgilanmagan.")
        return
    await message.answer(
        "🔥 **Eng ko‘p o‘qilayotgan bestseller kitoblar:**",
        reply_markup=books_list_inline_keyboard(books, back_callback="menu_main"),
        parse_mode="Markdown"
    )

@router.message(F.text == "🆕 Yangi kitoblar")
async def show_new_books(message: Message, session: AsyncSession) -> None:
    """Show newly released books."""
    books = await get_new_books(session)
    if not books:
        await message.answer("🆕 Hozircha yangi kitoblar mavjud emas.")
        return
    await message.answer(
        "🆕 **Neshriyotimizning eng yangi kitoblari:**",
        reply_markup=books_list_inline_keyboard(books, back_callback="menu_main"),
        parse_mode="Markdown"
    )

@router.callback_query(F.data.startswith("cat:"))
async def cb_category_books(callback: CallbackQuery, session: AsyncSession) -> None:
    """Show books belonging to selected category."""
    cat_id = int(callback.data.split(":")[1])
    category = await get_category_by_id(session, cat_id)
    books = await get_books_by_category(session, cat_id)

    cat_name = category.name if category else "Kategoriya"

    if not books:
        await callback.answer("Ushbu kategoriyada kitoblar yo‘q.", show_alert=True)
        return

    text = f"📂 **{cat_name}** bo‘limidagi kitoblar:"
    await callback.message.edit_text(
        text,
        reply_markup=books_list_inline_keyboard(books, back_callback="categories_list"),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("book_view:"))
async def cb_book_view(callback: CallbackQuery, session: AsyncSession) -> None:
    """Show preview book card."""
    book_id = int(callback.data.split(":")[1])
    book = await get_book_by_id(session, book_id)

    if not book:
        await callback.answer("Kitob topilmadi.", show_alert=True)
        return

    card_text = format_book_card(book, detailed=False)
    keyboard = book_card_inline_keyboard(book.id)

    # If photo exists, display photo message, else text
    if callback.message.photo:
        await callback.message.delete()
        if book.image_file_id:
            await callback.message.answer_photo(
                photo=book.image_file_id,
                caption=card_text,
                reply_markup=keyboard
            )
        else:
            await callback.message.answer(card_text, reply_markup=keyboard)
    else:
        if book.image_file_id:
            await callback.message.delete()
            await callback.message.answer_photo(
                photo=book.image_file_id,
                caption=card_text,
                reply_markup=keyboard
            )
        else:
            await callback.message.edit_text(card_text, reply_markup=keyboard)

    await callback.answer()

@router.callback_query(F.data.startswith("book_detail:"))
async def cb_book_detail(callback: CallbackQuery, session: AsyncSession) -> None:
    """Show detailed view of book."""
    book_id = int(callback.data.split(":")[1])
    book = await get_book_by_id(session, book_id)

    if not book:
        await callback.answer("Kitob topilmadi.", show_alert=True)
        return

    card_text = format_book_card(book, detailed=True)
    keyboard = book_details_inline_keyboard(book.id)

    if callback.message.photo:
        await callback.message.edit_caption(caption=card_text, reply_markup=keyboard)
    else:
        await callback.message.edit_text(card_text, reply_markup=keyboard)

    await callback.answer()
