from aiogram import Router
from .start import router as start_router
from .books import router as books_router
from .search import router as search_router
from .cart import router as cart_router
from .orders import router as orders_router
from .admin import router as admin_router

main_router = Router()

# Register admin_router first so admin commands and callback queries are handled with highest priority
main_router.include_router(admin_router)
main_router.include_router(start_router)
main_router.include_router(books_router)
main_router.include_router(search_router)
main_router.include_router(cart_router)
main_router.include_router(orders_router)

__all__ = ["main_router"]
