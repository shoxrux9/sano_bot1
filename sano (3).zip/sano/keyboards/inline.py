from typing import List
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database.models import Category, Book, CartItem, Menu, BotButton

def categories_inline_keyboard(categories: List[Category]) -> InlineKeyboardMarkup:
    builder = []
    for cat in categories:
        builder.append([InlineKeyboardButton(text=cat.name, callback_data=f"cat:{cat.id}")])
    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu_main")])
    return InlineKeyboardMarkup(inline_keyboard=builder)

def books_list_inline_keyboard(books: List[Book], back_callback: str = "categories_list") -> InlineKeyboardMarkup:
    builder = []
    for book in books:
        builder.append([InlineKeyboardButton(text=f"📕 {book.title} — {int(book.price):,} so'm", callback_data=f"book_view:{book.id}")])
    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data=back_callback)])
    return InlineKeyboardMarkup(inline_keyboard=builder)

def book_card_inline_keyboard(book_id: int) -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(text="📖 Batafsil", callback_data=f"book_detail:{book_id}"),
            InlineKeyboardButton(text="🛒 Savatga qo‘shish", callback_data=f"cart_add:{book_id}")
        ],
        [
            InlineKeyboardButton(text="🛍 Buyurtma berish", callback_data=f"buy_now:{book_id}")
        ],
        [
            InlineKeyboardButton(text="⬅️ Orqaga", callback_data="categories_list")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def book_details_inline_keyboard(book_id: int) -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(text="🛒 Savatga qo‘shish", callback_data=f"cart_add:{book_id}"),
            InlineKeyboardButton(text="🛍 Hozir buyurtma berish", callback_data=f"buy_now:{book_id}")
        ],
        [
            InlineKeyboardButton(text="⬅️ Orqaga", callback_data=f"book_view:{book_id}")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def cart_inline_keyboard(cart_items: List[CartItem]) -> InlineKeyboardMarkup:
    builder = []
    for item in cart_items:
        title = item.book.title if item.book else "Kitob"
        builder.append([InlineKeyboardButton(text=f"📖 {title} (x{item.quantity})", callback_data=f"book_view:{item.book_id}")])
        builder.append([
            InlineKeyboardButton(text="➖", callback_data=f"cart_dec:{item.id}"),
            InlineKeyboardButton(text=f"{item.quantity} dona", callback_data="noop"),
            InlineKeyboardButton(text="➕", callback_data=f"cart_inc:{item.id}"),
            InlineKeyboardButton(text="🗑 O‘chirish", callback_data=f"cart_del:{item.id}")
        ])

    if cart_items:
        builder.append([
            InlineKeyboardButton(text="🧹 Savatni tozalash", callback_data="cart_clear"),
            InlineKeyboardButton(text="✅ Buyurtma berish", callback_data="cart_checkout")
        ])
    
    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu_main")])
    return InlineKeyboardMarkup(inline_keyboard=builder)

def order_confirm_inline_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(text="✅ Tasdiqlash", callback_data="order_confirm"),
            InlineKeyboardButton(text="❌ Bekor qilish", callback_data="order_cancel")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def admin_order_inline_keyboard(order_id: int) -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(text="✅ Qabul qilish", callback_data=f"admin_order:confirmed:{order_id}"),
            InlineKeyboardButton(text="🚚 Yetkazishga berildi", callback_data=f"admin_order:shipping:{order_id}")
        ],
        [
            InlineKeyboardButton(text="✅ Yetkazildi", callback_data=f"admin_order:delivered:{order_id}"),
            InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"admin_order:cancelled:{order_id}")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def admin_main_inline_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(text="📚 Barcha kitoblar", callback_data="admin_books_list"),
            InlineKeyboardButton(text="➕ Kitob qo‘shish", callback_data="admin_book_add")
        ],
        [
            InlineKeyboardButton(text="✏️ Kitobni tahrirlash", callback_data="admin_book_edit_select"),
            InlineKeyboardButton(text="🗑 Kitobni o‘chirish", callback_data="admin_book_delete_select")
        ],
        [
            InlineKeyboardButton(text="📂 Kategoriyalar", callback_data="admin_categories"),
            InlineKeyboardButton(text="⚙️ Menularni boshqarish", callback_data="admin_menus")
        ],
        [
            InlineKeyboardButton(text="🎛️ Tugmalar boshqaruvi", callback_data="admin_buttons_list"),
            InlineKeyboardButton(text="📦 Buyurtmalar", callback_data="admin_orders_list")
        ],
        [
            InlineKeyboardButton(text="📊 Statistika", callback_data="admin_stats")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def admin_menus_list_keyboard(menus: List[Menu]) -> InlineKeyboardMarkup:
    builder = []
    for menu in menus:
        status_icon = "✅ Yoqilgan" if menu.is_active else "❌ O'chirilgan"
        builder.append([
            InlineKeyboardButton(
                text=f"{menu.title} [{status_icon}]",
                callback_data=f"admin_menu_manage:{menu.id}"
            )
        ])
    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")])
    return InlineKeyboardMarkup(inline_keyboard=builder)

def admin_single_menu_keyboard(menu: Menu) -> InlineKeyboardMarkup:
    toggle_text = "🔴 O'chirish" if menu.is_active else "🟢 Yoqish"
    keyboard = [
        [
            InlineKeyboardButton(text=f"🔄 {toggle_text}", callback_data=f"admin_menu_toggle:{menu.id}"),
            InlineKeyboardButton(text="✏️ Matnni o'zgartirish", callback_data=f"admin_menu_edit_text:{menu.id}")
        ],
        [
            InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_menus")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def admin_buttons_list_keyboard(buttons: List[BotButton]) -> InlineKeyboardMarkup:
    builder = []
    for btn in buttons:
        status_icon = "🟢 Yoqilgan" if btn.is_active else "🔴 O'chirilgan"
        builder.append([
            InlineKeyboardButton(
                text=f"{btn.title} [{status_icon}]",
                callback_data=f"admin_btn_manage:{btn.id}"
            )
        ])
    builder.append([InlineKeyboardButton(text="➕ Yangi tugma qo'shish", callback_data="admin_btn_add_custom")])
    builder.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_main")])
    return InlineKeyboardMarkup(inline_keyboard=builder)

def admin_single_button_keyboard(btn: BotButton) -> InlineKeyboardMarkup:
    toggle_text = "🔴 O'chirish" if btn.is_active else "🟢 Yoqish"
    keyboard = [
        [
            InlineKeyboardButton(text=f"🔄 {toggle_text}", callback_data=f"admin_btn_toggle:{btn.id}"),
            InlineKeyboardButton(text="✏️ Nomini o'zgartirish", callback_data=f"admin_btn_edit_title:{btn.id}")
        ],
        [
            InlineKeyboardButton(text="📝 Javob matnini o'zgartirish", callback_data=f"admin_btn_edit_text:{btn.id}")
        ],
        [
            InlineKeyboardButton(text="⬅️ Orqaga", callback_data="admin_buttons_list")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def admin_confirm_delete_keyboard(book_id: int) -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(text="✅ Ha, o‘chirish", callback_data=f"admin_book_delete_confirm:{book_id}"),
            InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin_book_delete_cancel")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def admin_confirm_delete_category_keyboard(cat_id: int) -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton(text="✅ Ha, o‘chirish", callback_data=f"admin_cat_delete_confirm:{cat_id}"),
            InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin_categories")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)
