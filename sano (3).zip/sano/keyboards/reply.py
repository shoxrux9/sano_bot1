from typing import List, Optional, Any
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def main_menu_keyboard(buttons: Optional[List[Any]] = None) -> ReplyKeyboardMarkup:
    """Build dynamic reply keyboard from active database buttons."""
    keyboard = []
    
    if buttons:
        row = []
        for btn in buttons:
            title = getattr(btn, "title", str(btn))
            row.append(KeyboardButton(text=title))
            if len(row) == 2:
                keyboard.append(row)
                row = []
        if row:
            keyboard.append(row)
    else:
        # Fallback default layout
        keyboard = [
            [
                KeyboardButton(text="📚 Kitoblar katalogi"),
                KeyboardButton(text="🛒 Savat"),
            ],
            [
                KeyboardButton(text="🔍 Qidiruv"),
                KeyboardButton(text="📦 Buyurtmalarim"),
            ],
            [
                KeyboardButton(text="📞 Aloqa"),
                KeyboardButton(text="ℹ️ Biz haqimizda"),
            ]
        ]

    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)

def contact_request_keyboard() -> ReplyKeyboardMarkup:
    keyboard = [
        [KeyboardButton(text="📱 Telefon raqamni yuborish", request_contact=True)],
        [KeyboardButton(text="⬅️ Bekor qilish")],
    ]
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)

def cancel_keyboard() -> ReplyKeyboardMarkup:
    keyboard = [
        [KeyboardButton(text="⬅️ Bekor qilish")]
    ]
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
