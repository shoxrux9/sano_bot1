from datetime import datetime, timedelta
from typing import List, Optional, Tuple, Dict, Any
from sqlalchemy import select, update, delete, func, or_, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from .models import User, Category, Book, CartItem, Order, OrderItem, Menu, BotButton

# --- BOT BUTTON CRUD ---
async def get_active_reply_buttons(session: AsyncSession) -> List[BotButton]:
    stmt = select(BotButton).where(
        BotButton.category_type == "main_reply",
        BotButton.is_active == True
    ).order_by(BotButton.sort_order.asc(), BotButton.id.asc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_all_buttons(session: AsyncSession) -> List[BotButton]:
    stmt = select(BotButton).order_by(BotButton.sort_order.asc(), BotButton.id.asc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_button_by_id(session: AsyncSession, button_id: int) -> Optional[BotButton]:
    stmt = select(BotButton).where(BotButton.id == button_id)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def get_button_by_key(session: AsyncSession, key: str) -> Optional[BotButton]:
    stmt = select(BotButton).where(BotButton.button_key == key)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def get_button_by_title(session: AsyncSession, title: str) -> Optional[BotButton]:
    stmt = select(BotButton).where(BotButton.title == title.strip())
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def toggle_button_status(session: AsyncSession, button_id: int) -> Optional[BotButton]:
    btn = await get_button_by_id(session, button_id)
    if btn:
        btn.is_active = not btn.is_active
        await session.commit()
        await session.refresh(btn)
    return btn

async def update_button_title(session: AsyncSession, button_id: int, new_title: str) -> Optional[BotButton]:
    btn = await get_button_by_id(session, button_id)
    if btn:
        btn.title = new_title.strip()
        await session.commit()
        await session.refresh(btn)
    return btn

async def update_button_reply_text(session: AsyncSession, button_id: int, new_reply_text: str) -> Optional[BotButton]:
    btn = await get_button_by_id(session, button_id)
    if btn:
        btn.reply_text = new_reply_text.strip()
        await session.commit()
        await session.refresh(btn)
    return btn

async def create_custom_button(session: AsyncSession, title: str, reply_text: str) -> BotButton:
    # Generate unique button key
    count_stmt = select(func.count(BotButton.id))
    res = await session.execute(count_stmt)
    count = res.scalar_one()
    
    key = f"btn_custom_{count + 1}"
    btn = BotButton(
        button_key=key,
        title=title.strip(),
        reply_text=reply_text.strip(),
        category_type="main_reply",
        is_active=True,
        sort_order=count + 10
    )
    session.add(btn)
    await session.commit()
    await session.refresh(btn)
    return btn


# --- MENU CRUD ---
async def get_all_menus(session: AsyncSession) -> List[Menu]:
    stmt = select(Menu).order_by(Menu.id.asc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_active_menus(session: AsyncSession) -> List[Menu]:
    stmt = select(Menu).where(Menu.is_active == True).order_by(Menu.id.asc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_menu_by_id(session: AsyncSession, menu_id: int) -> Optional[Menu]:
    stmt = select(Menu).where(Menu.id == menu_id)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def get_menu_by_title(session: AsyncSession, title: str) -> Optional[Menu]:
    stmt = select(Menu).where(Menu.title == title.strip(), Menu.is_active == True)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def toggle_menu_status(session: AsyncSession, menu_id: int) -> Optional[Menu]:
    menu = await get_menu_by_id(session, menu_id)
    if menu:
        menu.is_active = not menu.is_active
        await session.commit()
        await session.refresh(menu)
    return menu

async def update_menu_content(session: AsyncSession, menu_id: int, content: str) -> Optional[Menu]:
    menu = await get_menu_by_id(session, menu_id)
    if menu:
        menu.content = content.strip()
        await session.commit()
        await session.refresh(menu)
    return menu


# --- USER CRUD ---
async def get_or_create_user(
    session: AsyncSession,
    telegram_id: int,
    username: Optional[str] = None,
    full_name: Optional[str] = None
) -> User:
    stmt = select(User).where(User.telegram_id == telegram_id)
    result = await session.execute(stmt)
    user = result.scalar_one_or_none()

    if not user:
        user = User(
            telegram_id=telegram_id,
            username=username,
            full_name=full_name
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
    else:
        # Update details if changed
        updated = False
        if username and user.username != username:
            user.username = username
            updated = True
        if full_name and user.full_name != full_name:
            user.full_name = full_name
            updated = True
        if updated:
            await session.commit()
            await session.refresh(user)

    return user

async def update_user_phone(session: AsyncSession, user_id: int, phone: str) -> None:
    stmt = update(User).where(User.id == user_id).values(phone=phone)
    await session.execute(stmt)
    await session.commit()

# --- CATEGORY CRUD ---
async def get_categories(session: AsyncSession) -> List[Category]:
    stmt = select(Category).order_by(Category.name.asc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_category_by_id(session: AsyncSession, category_id: int) -> Optional[Category]:
    stmt = select(Category).where(Category.id == category_id)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def create_category(session: AsyncSession, name: str) -> Category:
    category = Category(name=name)
    session.add(category)
    await session.commit()
    await session.refresh(category)
    return category

async def delete_category(session: AsyncSession, category_id: int) -> bool:
    stmt = delete(Category).where(Category.id == category_id)
    result = await session.execute(stmt)
    await session.commit()
    return result.rowcount > 0

# --- BOOK CRUD ---
async def get_books_by_category(session: AsyncSession, category_id: int) -> List[Book]:
    stmt = select(Book).options(selectinload(Book.category)).where(Book.category_id == category_id).order_by(Book.id.desc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_bestseller_books(session: AsyncSession) -> List[Book]:
    stmt = select(Book).options(selectinload(Book.category)).where(Book.is_bestseller == True).order_by(Book.id.desc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_new_books(session: AsyncSession) -> List[Book]:
    stmt = select(Book).options(selectinload(Book.category)).where(Book.is_new == True).order_by(Book.id.desc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def search_books(session: AsyncSession, query: str) -> List[Book]:
    pattern = f"%{query.strip()}%"
    stmt = select(Book).options(selectinload(Book.category)).where(
        or_(
            Book.title.ilike(pattern),
            Book.author.ilike(pattern)
        )
    ).order_by(Book.title.asc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_book_by_id(session: AsyncSession, book_id: int) -> Optional[Book]:
    stmt = select(Book).options(selectinload(Book.category)).where(Book.id == book_id)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def create_book(
    session: AsyncSession,
    title: str,
    author: str,
    category_id: int,
    description: str,
    price: float,
    pages: int,
    format: str,
    image_file_id: Optional[str] = None,
    is_bestseller: bool = False,
    is_new: bool = False
) -> Book:
    book = Book(
        title=title,
        author=author,
        category_id=category_id,
        description=description,
        price=price,
        pages=pages,
        format=format,
        image_file_id=image_file_id,
        is_bestseller=is_bestseller,
        is_new=is_new
    )
    session.add(book)
    await session.commit()
    await session.refresh(book)
    return book

async def update_book(session: AsyncSession, book_id: int, **kwargs) -> Optional[Book]:
    stmt = update(Book).where(Book.id == book_id).values(**kwargs)
    await session.execute(stmt)
    await session.commit()
    return await get_book_by_id(session, book_id)

async def delete_book(session: AsyncSession, book_id: int) -> bool:
    stmt = delete(Book).where(Book.id == book_id)
    result = await session.execute(stmt)
    await session.commit()
    return result.rowcount > 0

# --- CART CRUD ---
async def get_cart(session: AsyncSession, user_id: int) -> List[CartItem]:
    stmt = select(CartItem).options(selectinload(CartItem.book)).where(CartItem.user_id == user_id).order_by(CartItem.id.asc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def add_to_cart(session: AsyncSession, user_id: int, book_id: int, quantity: int = 1) -> CartItem:
    stmt = select(CartItem).where(CartItem.user_id == user_id, CartItem.book_id == book_id)
    result = await session.execute(stmt)
    item = result.scalar_one_or_none()

    if item:
        item.quantity += quantity
    else:
        item = CartItem(user_id=user_id, book_id=book_id, quantity=quantity)
        session.add(item)

    await session.commit()
    await session.refresh(item)
    return item

async def update_cart_quantity(session: AsyncSession, cart_item_id: int, delta: int) -> Optional[CartItem]:
    stmt = select(CartItem).where(CartItem.id == cart_item_id)
    result = await session.execute(stmt)
    item = result.scalar_one_or_none()

    if not item:
        return None

    new_qty = item.quantity + delta
    if new_qty <= 0:
        await session.delete(item)
        await session.commit()
        return None
    else:
        item.quantity = new_qty
        await session.commit()
        await session.refresh(item)
        return item

async def remove_cart_item(session: AsyncSession, cart_item_id: int) -> bool:
    stmt = delete(CartItem).where(CartItem.id == cart_item_id)
    result = await session.execute(stmt)
    await session.commit()
    return result.rowcount > 0

async def clear_cart(session: AsyncSession, user_id: int) -> None:
    stmt = delete(CartItem).where(CartItem.user_id == user_id)
    await session.execute(stmt)
    await session.commit()

# --- ORDER CRUD ---
async def create_order(
    session: AsyncSession,
    user_id: int,
    phone: str,
    address: str,
    comment: Optional[str] = None
) -> Tuple[Optional[Order], List[OrderItem]]:
    cart_items = await get_cart(session, user_id)
    if not cart_items:
        return None, []

    total_price = sum(item.quantity * item.book.price for item in cart_items if item.book)

    order = Order(
        user_id=user_id,
        total_price=total_price,
        status="new",
        phone=phone,
        address=address,
        comment=comment
    )
    session.add(order)
    await session.flush() # get order.id

    order_items = []
    for item in cart_items:
        if item.book:
            o_item = OrderItem(
                order_id=order.id,
                book_id=item.book_id,
                quantity=item.quantity,
                price=item.book.price
            )
            session.add(o_item)
            order_items.append(o_item)

    # Clear user's shopping cart after creating order
    await session.execute(delete(CartItem).where(CartItem.user_id == user_id))
    await session.commit()
    await session.refresh(order)

    # Reload with relationships
    stmt = select(Order).options(
        selectinload(Order.user),
        selectinload(Order.order_items).selectinload(OrderItem.book)
    ).where(Order.id == order.id)
    res = await session.execute(stmt)
    full_order = res.scalar_one()

    return full_order, full_order.order_items

async def get_order_by_id(session: AsyncSession, order_id: int) -> Optional[Order]:
    stmt = select(Order).options(
        selectinload(Order.user),
        selectinload(Order.order_items).selectinload(OrderItem.book)
    ).where(Order.id == order_id)
    result = await session.execute(stmt)
    return result.scalar_one_or_none()

async def update_order_status(session: AsyncSession, order_id: int, status: str) -> Optional[Order]:
    stmt = update(Order).where(Order.id == order_id).values(status=status)
    await session.execute(stmt)
    await session.commit()
    return await get_order_by_id(session, order_id)

async def get_user_orders(session: AsyncSession, user_id: int) -> List[Order]:
    stmt = select(Order).options(
        selectinload(Order.order_items).selectinload(OrderItem.book)
    ).where(Order.user_id == user_id).order_by(Order.id.desc())
    result = await session.execute(stmt)
    return list(result.scalars().all())

async def get_all_orders(session: AsyncSession, limit: int = 50) -> List[Order]:
    stmt = select(Order).options(
        selectinload(Order.user),
        selectinload(Order.order_items).selectinload(OrderItem.book)
    ).order_by(Order.id.desc()).limit(limit)
    result = await session.execute(stmt)
    return list(result.scalars().all())

# --- ADMIN STATISTICS ---
async def get_admin_stats(session: AsyncSession) -> Dict[str, Any]:
    now = datetime.now()
    today_start = datetime(now.year, now.month, now.day)
    seven_days_ago = now - timedelta(days=7)
    thirty_days_ago = now - timedelta(days=30)

    # Today's orders & revenue
    today_stmt = select(
        func.count(Order.id),
        func.coalesce(func.sum(Order.total_price), 0.0)
    ).where(Order.created_at >= today_start, Order.status != "cancelled")
    res_today = await session.execute(today_stmt)
    today_count, today_revenue = res_today.one()

    # 7 days count & revenue
    stmt_7d = select(
        func.count(Order.id),
        func.coalesce(func.sum(Order.total_price), 0.0)
    ).where(Order.created_at >= seven_days_ago, Order.status != "cancelled")
    res_7d = await session.execute(stmt_7d)
    count_7d, revenue_7d = res_7d.one()

    # 30 days count & revenue
    stmt_30d = select(
        func.count(Order.id),
        func.coalesce(func.sum(Order.total_price), 0.0)
    ).where(Order.created_at >= thirty_days_ago, Order.status != "cancelled")
    res_30d = await session.execute(stmt_30d)
    count_30d, revenue_30d = res_30d.one()

    # Total orders & revenue
    total_stmt = select(
        func.count(Order.id),
        func.coalesce(func.sum(Order.total_price), 0.0)
    ).where(Order.status != "cancelled")
    res_total = await session.execute(total_stmt)
    total_count, total_revenue = res_total.one()

    # Total books sold
    sold_books_stmt = select(func.coalesce(func.sum(OrderItem.quantity), 0)).join(Order).where(Order.status != "cancelled")
    res_sold = await session.execute(sold_books_stmt)
    total_books_sold = res_sold.scalar_one()

    # Bestselling book name
    top_book_stmt = select(
        Book.title,
        func.sum(OrderItem.quantity).label("sold_qty")
    ).join(OrderItem, Book.id == OrderItem.book_id).join(Order, Order.id == OrderItem.order_id)\
    .where(Order.status != "cancelled")\
    .group_by(Book.id)\
    .order_by(desc("sold_qty"))\
    .limit(1)
    res_top = await session.execute(top_book_stmt)
    top_book_row = res_top.one_or_none()
    top_book_name = top_book_row[0] if top_book_row else "Ma’lumot yo‘q"

    # Status counts
    status_stmt = select(Order.status, func.count(Order.id)).group_by(Order.status)
    res_status = await session.execute(status_stmt)
    status_counts = dict(res_status.all())

    return {
        "today_orders": today_count,
        "today_revenue": today_revenue,
        "count_7d": count_7d,
        "revenue_7d": revenue_7d,
        "count_30d": count_30d,
        "revenue_30d": revenue_30d,
        "total_orders": total_count,
        "total_revenue": total_revenue,
        "total_books_sold": total_books_sold,
        "bestseller_title": top_book_name,
        "status_counts": status_counts
    }
