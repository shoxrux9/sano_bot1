import asyncio
import os
import sys

# Ensure workspace root is in python path if run directly
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sqlalchemy import select, delete
from database.db import AsyncSessionLocal, init_db
from database.models import Category, Book, CartItem, OrderItem, Menu, BotButton

DEMO_CATEGORIES = [
    "🔥 Best Seller",
    "👶 Bolalar uchun",
    "📚 Diniy va Ma'rifiy",
]

DEMO_BUTTONS = [
    {
        "button_key": "btn_catalog",
        "title": "📚 Kitoblar katalogi",
        "reply_text": None,
        "category_type": "main_reply",
        "is_active": True,
        "sort_order": 1,
    },
    {
        "button_key": "btn_cart",
        "title": "🛒 Savat",
        "reply_text": None,
        "category_type": "main_reply",
        "is_active": True,
        "sort_order": 2,
    },
    {
        "button_key": "btn_search",
        "title": "🔍 Qidiruv",
        "reply_text": None,
        "category_type": "main_reply",
        "is_active": True,
        "sort_order": 3,
    },
    {
        "button_key": "btn_my_orders",
        "title": "📦 Buyurtmalarim",
        "reply_text": None,
        "category_type": "main_reply",
        "is_active": True,
        "sort_order": 4,
    },
    {
        "button_key": "btn_contact",
        "title": "📞 Aloqa",
        "reply_text": (
            "📞 **BOG'LANISH HIZMATI**\n\n"
            "Savollar yoki takliflar bormi? Biz bilan bog'laning:\n\n"
            "📱 Telefon: +998 (90) 123-45-67\n"
            "💬 Telegram: @shokhruxdev1\n"
            "⏰ Ish vaqti: 08:00 - 18:00 (Dushanba - Shanba)"
        ),
        "category_type": "main_reply",
        "is_active": True,
        "sort_order": 5,
    },
    {
        "button_key": "btn_about",
        "title": "ℹ️ Biz haqimizda",
        "reply_text": (
            "📚 **SANO BOOKS Nashriyoti**\n\n"
            "Biz sizga eng sara va ma'naviy boy kitoblarni taqdim etamiz.\n"
            "Badiiy, psixologiya, diniy-ma'rifiy hamda bolalar adabiyotlari.\n\n"
            "📍 Manzil: Toshkent sh., shiroq, 34 \n"
            "📞 Telefon: +998 (90) 123-45-67\n"
            "🌐 Veb-sayt: www.sano.uz"
        ),
        "category_type": "main_reply",
        "is_active": True,
        "sort_order": 6,
    },
]

DEMO_BOOKS = [
    # 🔥 Best Seller
    {
        "category_name": "🔥 Best Seller",
        "title": "O'qing faqat yig'lamang 1-qism",
        "author": "Sano Books",
        "description": "Ta'sirli va ibratli hikoyalar to'plami. 1-qism.",
        "price": 15000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "🔥 Best Seller",
        "title": "O'qing faqat yig'lamang 2-qism",
        "author": "Sano Books",
        "description": "Ta'sirli va ibratli hikoyalar to'plami. 2-qism.",
        "price": 15000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "🔥 Best Seller",
        "title": "O'qing faqat yig'lamang 3-qism",
        "author": "Sano Books",
        "description": "Ta'sirli va ibratli hikoyalar to'plami. 3-qism.",
        "price": 15000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "🔥 Best Seller",
        "title": "O'qing faqat yig'lamang 4-qism",
        "author": "Sano Books",
        "description": "Ta'sirli va ibratli hikoyalar to'plami. 4-qism.",
        "price": 15000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "🔥 Best Seller",
        "title": "Umidvor bo'ling 1-qism",
        "author": "Sano Books",
        "description": "Qalbga taskin beruvchi ma'naviy asar. 1-qism.",
        "price": 45000.0,
        "pages": 624,
        "format": "145×215 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "🔥 Best Seller",
        "title": "Umidvor bo'ling 2-qism",
        "author": "Sano Books",
        "description": "Qalbga taskin beruvchi ma'naviy asar. 2-qism.",
        "price": 45000.0,
        "pages": 624,
        "format": "145×215 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "🔥 Best Seller",
        "title": "Sevgi yomg'irni sevar",
        "author": "Sano Books",
        "description": "Samimiy tuyg'ular va muhabbat haqida go'zal kitob.",
        "price": 15000.0,
        "pages": 200,
        "format": "135×210 mm",
        "is_bestseller": True,
        "is_new": True,
    },

    # 👶 Bolalar uchun
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Bolalarga gap uqtirish san'ati 1-qism",
        "author": "Sano Books",
        "description": "Ota-onalar uchun bolalar tarbiyasi va muloqot sirlari. 1-qism.",
        "price": 14000.0,
        "pages": 256,
        "format": "145×215 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Bolalarga gap uqtirish san'ati 2-qism",
        "author": "Sano Books",
        "description": "Ota-onalar uchun bolalar tarbiyasi va muloqot sirlari. 2-qism.",
        "price": 14000.0,
        "pages": 256,
        "format": "145×215 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Bolalarga gap uqtirish san'ati 3-qism",
        "author": "Sano Books",
        "description": "Ota-onalar uchun bolalar tarbiyasi va muloqot sirlari. 3-qism.",
        "price": 14000.0,
        "pages": 256,
        "format": "145×215 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Donishmand dehqon",
        "author": "Sano Books",
        "description": "Bolalar uchun va'z va hikmatli ertaklar.",
        "price": 11000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "40 odob va hikmat 1-qism",
        "author": "Sano Books",
        "description": "Bolalar uchun chiroyli odob va axloq saboqlari. 1-qism.",
        "price": 8000.0,
        "pages": 96,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "40 odob va hikmat 2-qism",
        "author": "Sano Books",
        "description": "Bolalar uchun chiroyli odob va axloq saboqlari. 2-qism.",
        "price": 8000.0,
        "pages": 64,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Ikki qaysar echki",
        "author": "Sano Books",
        "description": "Qiziqarli va tarbiyaviy bolalar ertagi.",
        "price": 11000.0,
        "pages": 96,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Mahmadona quyon",
        "author": "Sano Books",
        "description": "Shoh va quyon haqidagi zavqli ertak.",
        "price": 11000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Alifbe",
        "author": "Sano Books",
        "description": "Kichkintoylar uchun rasmli va qulay Alifbe kitobi.",
        "price": 15000.0,
        "pages": 176,
        "format": "145×215 mm",
        "is_bestseller": False,
        "is_new": True,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Rasulullohni ko'rgan bolalar",
        "author": "Sano Books",
        "description": "Sahoba bolalarning Payg'ambarimiz (s.a.v.) bilan kechgan hayotiy voqealari.",
        "price": 17000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": True,
    },
    {
        "category_name": "👶 Bolalar uchun",
        "title": "Oilam bilan har kun bir hayot darsi o'rganamiz",
        "author": "Sano Books",
        "description": "Oila davrasida o'qiladigan 365 kunlik ibratli saboqlar.",
        "price": 15000.0,
        "pages": 352,
        "format": "145×215 mm",
        "is_bestseller": False,
        "is_new": True,
    },

    # 📚 Diniy va Ma'rifiy
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Saodatga yetaklovchi hikmatlar 1-qism",
        "author": "Sano Books",
        "description": "Diniy va ma'rifiy hikmatlar hamda o'gitlar to'plami. 1-qism.",
        "price": 20000.0,
        "pages": 200,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Saodatga yetaklovchi hikmatlar 2-qism",
        "author": "Sano Books",
        "description": "Diniy va ma'rifiy hikmatlar hamda o'gitlar to'plami. 2-qism.",
        "price": 20000.0,
        "pages": 200,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Saodatga yetaklovchi hikmatlar 3-qism",
        "author": "Sano Books",
        "description": "Diniy va ma'rifiy hikmatlar hamda o'gitlar to'plami. 3-qism.",
        "price": 20000.0,
        "pages": 200,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Saodatga yetaklovchi hikmatlar 4-qism",
        "author": "Sano Books",
        "description": "Diniy va ma'rifiy hikmatlar hamda o'gitlar to'plami. 4-qism.",
        "price": 20000.0,
        "pages": 200,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Ibodati Islomiya",
        "author": "Sano Books",
        "description": "Islomiy ibodatlar va fiqhiy qoidalar bo'yicha mukammal qo'llanma.",
        "price": 15000.0,
        "pages": 180,
        "format": "145×215 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Besh vaqt namoz va duolar A5",
        "author": "Sano Books",
        "description": "Namoz o'rganuvchilar uchun A5 formatdagi qulay qo'llanma.",
        "price": 8000.0,
        "pages": 96,
        "format": "A5 (148×210 mm)",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Besh vaqt namoz va duolar A4",
        "author": "Sano Books",
        "description": "Namoz o'rganuvchilar uchun A4 formatdagi yirik shriftli qo'llanma.",
        "price": 12000.0,
        "pages": 96,
        "format": "A4 (210×297 mm)",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Olamlarga rahmat Payg'ambar",
        "author": "Sano Books",
        "description": "Payg'ambarimiz Muhammad (s.a.v.) hayotlari va go'zal xulqlari.",
        "price": 30000.0,
        "pages": 240,
        "format": "145×215 mm",
        "is_bestseller": True,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Rasulullohni bir kuni",
        "author": "Sano Books",
        "description": "Payg'ambarimiz (s.a.v.) kunlik hayotlari, ibodatlari va odatlari.",
        "price": 15000.0,
        "pages": 160,
        "format": "135×210 mm",
        "is_bestseller": False,
        "is_new": False,
    },
    {
        "category_name": "📚 Diniy va Ma'rifiy",
        "title": "Muallimi soniy",
        "author": "Sano Books",
        "description": "Qur'on o'qishni o'rganuvchilar uchun tajvid qoidalari kitobi.",
        "price": 13000.0,
        "pages": 120,
        "format": "145×215 mm",
        "is_bestseller": False,
        "is_new": False,
    },
]

async def seed_data(force_reseed: bool = True):
    """Populate database with updated categories, books, and bot buttons."""
    await init_db()
    async with AsyncSessionLocal() as session:
        if force_reseed:
            await session.execute(delete(CartItem))
            await session.execute(delete(OrderItem))
            await session.execute(delete(Book))
            await session.execute(delete(Category))
            await session.execute(delete(Menu))
            await session.execute(delete(BotButton))
            await session.commit()

        # Seed categories
        cat_map = {}
        for cat_name in DEMO_CATEGORIES:
            res = await session.execute(select(Category).where(Category.name == cat_name))
            cat = res.scalar_one_or_none()
            if not cat:
                cat = Category(name=cat_name)
                session.add(cat)
                await session.flush()
            cat_map[cat_name] = cat.id

        await session.commit()

        # Seed books
        for book_info in DEMO_BOOKS:
            cat_id = cat_map.get(book_info["category_name"])
            if cat_id:
                res = await session.execute(select(Book).where(Book.title == book_info["title"]))
                existing = res.scalar_one_or_none()
                if not existing:
                    book = Book(
                        category_id=cat_id,
                        title=book_info["title"],
                        author=book_info["author"],
                        description=book_info["description"],
                        price=book_info["price"],
                        pages=book_info["pages"],
                        format=book_info["format"],
                        is_bestseller=book_info["is_bestseller"],
                        is_new=book_info["is_new"],
                    )
                    session.add(book)

        # Seed bot_buttons
        for btn_info in DEMO_BUTTONS:
            res = await session.execute(select(BotButton).where(BotButton.button_key == btn_info["button_key"]))
            existing_btn = res.scalar_one_or_none()
            if not existing_btn:
                btn = BotButton(
                    button_key=btn_info["button_key"],
                    title=btn_info["title"],
                    reply_text=btn_info["reply_text"],
                    category_type=btn_info["category_type"],
                    is_active=btn_info["is_active"],
                    sort_order=btn_info["sort_order"],
                )
                session.add(btn)

        await session.commit()
        print("Updated catalog and bot_buttons seed data applied!")

if __name__ == "__main__":
    asyncio.run(seed_data(force_reseed=True))
